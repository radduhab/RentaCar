package rentacarmain;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author raddu
 */
public class CarController {

    DBConnection con = new DBConnection();
    Connection conn = con.getConnection();

    public ArrayList<Car> getAll() {

        ArrayList<Car> cars = new ArrayList<Car>();
        String query = "SELECT * FROM Masini";
        try {
            Statement s = conn.createStatement();
            ResultSet rs = s.executeQuery(query);

            while (rs.next()) {
                Car c = new Car();
                c.setID(rs.getInt(1));
                c.setModelMasina(rs.getString(2));
                c.setAnFabricatie(rs.getInt(3));
                c.setCombustibil(rs.getString(4));
                c.setCaroserie(rs.getString(5));
                c.setTransmisie(rs.getString(6));
                c.setPrice(rs.getInt(7));

                cars.add(c);
            }

        } catch (SQLException ex) {
            Logger.getLogger(UserController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return cars;
    }

    public Car getByNume(String modelMasina) {
        String query = "Select * from Masini where modelMasina='" + modelMasina + "'";
        Car newcar = new Car();
        try {
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(query);
            while (rs.next()) {
                newcar.setID(rs.getInt("ID"));
                newcar.setModelMasina(rs.getString("modelMasina"));
                newcar.setAnFabricatie(rs.getInt("anFabricatie"));
                newcar.setCombustibil(rs.getString("combustibil"));
                newcar.setCaroserie(rs.getString("caroserie"));
                newcar.setTransmisie(rs.getString("Transmission"));
                newcar.setPrice(rs.getInt("Price"));

            }
        } catch (SQLException ex) {
            Logger.getLogger(Car.class.getName()).log(Level.SEVERE, null, ex);
        }
        return newcar;
    }

}
