/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rentacarmain;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author raddu
 */
public class ReservationController {

    DBConnection con = new DBConnection();
    Connection conn = con.getConnection();

    public ArrayList<Reservation> getAll() {

        ArrayList<Reservation> reservationList = new ArrayList<Reservation>();
        String query = "select * from Reservation WHERE Status='Pending'";
        try {
            Statement s = conn.createStatement();
            ResultSet rs = s.executeQuery(query);

            while (rs.next()) {
                Reservation res = new Reservation();
                res.setId(rs.getInt(1));
                res.setIdCar(rs.getInt(2));
                res.setIdUser(rs.getInt(3));
                res.setNrZile(rs.getInt(4));
                res.setStatus(rs.getString(5));
                reservationList.add(res);
            }

        } catch (SQLException ex) {
            Logger.getLogger(UserController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return reservationList;
    }

    public Reservation getById(int id) {
        String query = "Select * from Reservation where ID=" + id;
        Reservation res = new Reservation();
        try {
            Statement st = conn.createStatement();

            ResultSet rs = st.executeQuery(query);
            while (rs.next()) {
                res.setId(rs.getInt(1));
                res.setIdUser(rs.getInt(2));
                res.setIdCar(rs.getInt(3));
                res.setNrZile(rs.getInt(4));
                res.setStatus(rs.getString(5));

            }
        } catch (SQLException ex) {
            Logger.getLogger(CarController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return res;
    }

    public void add(Reservation res) {
        try {
            String query = "INSERT INTO Reservation "
                    + "(idCar,idUser ,"
                    + " nrZile, Status )"
                    + "Values(" + res.getIdCar() + ","
                    + res.getIdUser() + ","
                    + res.getNrZile() + ",'"
                    + res.getStatus() + "')";
            Statement s = conn.createStatement();
            s.executeUpdate(query);
        } catch (SQLException ex) {
            Logger.getLogger(ReservationController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public void approveReservation(Reservation res) {
        try {
            PreparedStatement pst;
            pst = conn.prepareStatement("update Reservation set Status='Approved' where ID=?");
            pst.setInt(1, res.getId());
            pst.executeUpdate();

        } catch (SQLException ex) {
            Logger.getLogger(ReservationController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public void rejectReservation(Reservation res) {
        String query = "update Reservation set Status = 'Rejected' where Id = " + res.getId();
        try {
            Statement s = conn.createStatement();
            s.executeUpdate(query);
        } catch (SQLException ex) {
            Logger.getLogger(ReservationController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
