package rentacarmain;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author raddu
 */
public class CarController {

    DBConnection con = new DBConnection();
    Connection conn = con.getConnection();

    public ArrayList<Car> getAll() {

        ArrayList<Car> cars = new ArrayList<Car>();
        String query = "SELECT * FROM Masini";
        try {
            Statement s = conn.createStatement();
            ResultSet rs = s.executeQuery(query);

            while (rs.next()) {
                Car c = new Car();
                c.setID(rs.getInt("ID"));
                c.setModelMasina("modelMasina");
                c.setAnFabricatie(rs.getInt("anFabricatie"));

                cars.add(c);
            }

        } catch (SQLException ex) {
            Logger.getLogger(UserController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return cars;
    }

}
