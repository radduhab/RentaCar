package rentacarmain;


 //@author raddu
public class RentaCarMain {

    public static void main(String[] args) {
       MainForm m = new MainForm();
       m.setVisible(true);
    }
    
}
