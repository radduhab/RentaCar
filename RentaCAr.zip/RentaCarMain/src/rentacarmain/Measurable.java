package rentacarmain;

/**
 *
 * @author raddu
 */
public interface Measurable {
    public void measureReservation();
}
