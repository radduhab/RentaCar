package rentacarmain;

//@author raddu

public class RentaCarMain {

    public static void main(String[] args) {
        LoginForm lf = new LoginForm();
        lf.setVisible(true);

    }

}
